﻿namespace projeto_ludico.Models
{
    public class InstitutionsModel
    {
        // Propriedades
        public int id { get; set; }
        public string name { get; set; }

        public InstitutionsModel() { }
    }
}
