﻿namespace projeto_ludico.Models
{
    public class PlacesModel
    {
        // Propriedades
        public int id { get; set; }
        public string name { get; set; }

        public PlacesModel() { }
    }
}
