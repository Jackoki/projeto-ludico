﻿namespace projeto_ludico.Models
{
    public class RPGModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public RPGModel() { }
    }
}
